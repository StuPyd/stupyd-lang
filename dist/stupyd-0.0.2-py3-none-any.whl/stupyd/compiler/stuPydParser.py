# Generated from /Users/muchen/python_smc/stupyd_demo_3/stuPyd.g4 by ANTLR 4.7
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\36")
        buf.write("\u0087\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\3\2\6\2 \n\2\r\2\16\2!\3\3\3\3\3\3\3\3")
        buf.write("\5\3(\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\5\6\5\61\n\5\r\5\16")
        buf.write("\5\62\3\6\3\6\3\6\3\6\3\7\3\7\3\b\3\b\3\b\7\b>\n\b\f\b")
        buf.write("\16\bA\13\b\3\b\3\b\3\t\3\t\3\t\3\n\3\n\3\13\3\13\3\13")
        buf.write("\3\13\3\13\3\13\3\13\3\13\3\13\7\13S\n\13\f\13\16\13V")
        buf.write("\13\13\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\7\fa\n\f\f")
        buf.write("\f\16\fd\13\f\3\r\3\r\3\r\3\r\3\r\3\r\5\rl\n\r\3\r\3\r")
        buf.write("\3\r\7\rq\n\r\f\r\16\rt\13\r\3\16\3\16\3\16\3\16\3\16")
        buf.write("\3\16\3\16\3\16\3\16\5\16\177\n\16\3\17\3\17\3\17\3\17")
        buf.write("\3\17\3\17\3\17\2\5\24\26\30\20\2\4\6\b\n\f\16\20\22\24")
        buf.write("\26\30\32\34\2\3\3\2\4\t\2\u008a\2\37\3\2\2\2\4\'\3\2")
        buf.write("\2\2\6)\3\2\2\2\b\60\3\2\2\2\n\64\3\2\2\2\f8\3\2\2\2\16")
        buf.write(":\3\2\2\2\20D\3\2\2\2\22G\3\2\2\2\24I\3\2\2\2\26W\3\2")
        buf.write("\2\2\30k\3\2\2\2\32~\3\2\2\2\34\u0080\3\2\2\2\36 \5\4")
        buf.write("\3\2\37\36\3\2\2\2 !\3\2\2\2!\37\3\2\2\2!\"\3\2\2\2\"")
        buf.write("\3\3\2\2\2#(\5\b\5\2$(\5\6\4\2%(\5\24\13\2&(\5\34\17\2")
        buf.write("\'#\3\2\2\2\'$\3\2\2\2\'%\3\2\2\2\'&\3\2\2\2(\5\3\2\2")
        buf.write("\2)*\5\24\13\2*+\7\3\2\2+,\5\22\n\2,-\7\30\2\2-.\b\4\1")
        buf.write("\2.\7\3\2\2\2/\61\5\n\6\2\60/\3\2\2\2\61\62\3\2\2\2\62")
        buf.write("\60\3\2\2\2\62\63\3\2\2\2\63\t\3\2\2\2\64\65\5\f\7\2\65")
        buf.write("\66\5\16\b\2\66\67\7\30\2\2\67\13\3\2\2\289\t\2\2\29\r")
        buf.write("\3\2\2\2:?\5\20\t\2;<\7\n\2\2<>\5\20\t\2=;\3\2\2\2>A\3")
        buf.write("\2\2\2?=\3\2\2\2?@\3\2\2\2@B\3\2\2\2A?\3\2\2\2BC\b\b\1")
        buf.write("\2C\17\3\2\2\2DE\7\31\2\2EF\b\t\1\2F\21\3\2\2\2GH\7\31")
        buf.write("\2\2H\23\3\2\2\2IJ\b\13\1\2JK\5\26\f\2KT\3\2\2\2LM\f\5")
        buf.write("\2\2MN\7\13\2\2NS\5\26\f\2OP\f\4\2\2PQ\7\f\2\2QS\5\26")
        buf.write("\f\2RL\3\2\2\2RO\3\2\2\2SV\3\2\2\2TR\3\2\2\2TU\3\2\2\2")
        buf.write("U\25\3\2\2\2VT\3\2\2\2WX\b\f\1\2XY\5\30\r\2Yb\3\2\2\2")
        buf.write("Z[\f\5\2\2[\\\7\r\2\2\\a\5\30\r\2]^\f\4\2\2^_\7\16\2\2")
        buf.write("_a\5\30\r\2`Z\3\2\2\2`]\3\2\2\2ad\3\2\2\2b`\3\2\2\2bc")
        buf.write("\3\2\2\2c\27\3\2\2\2db\3\2\2\2ef\b\r\1\2fg\7\17\2\2gl")
        buf.write("\5\30\r\6hi\7\f\2\2il\5\30\r\5jl\5\32\16\2ke\3\2\2\2k")
        buf.write("h\3\2\2\2kj\3\2\2\2lr\3\2\2\2mn\f\4\2\2no\7\20\2\2oq\5")
        buf.write("\32\16\2pm\3\2\2\2qt\3\2\2\2rp\3\2\2\2rs\3\2\2\2s\31\3")
        buf.write("\2\2\2tr\3\2\2\2u\177\7\26\2\2vw\7\21\2\2wx\5\24\13\2")
        buf.write("xy\7\22\2\2y\177\3\2\2\2z\177\7\23\2\2{\177\7\24\2\2|")
        buf.write("\177\7\34\2\2}\177\5\22\n\2~u\3\2\2\2~v\3\2\2\2~z\3\2")
        buf.write("\2\2~{\3\2\2\2~|\3\2\2\2~}\3\2\2\2\177\33\3\2\2\2\u0080")
        buf.write("\u0081\7\25\2\2\u0081\u0082\7\21\2\2\u0082\u0083\7\31")
        buf.write("\2\2\u0083\u0084\7\22\2\2\u0084\u0085\7\30\2\2\u0085\35")
        buf.write("\3\2\2\2\r!\'\62?RT`bkr~")
        return buf.getvalue()


class stuPydParser ( Parser ):

    grammarFileName = "stuPyd.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'->'", "'int'", "'real'", "'bool'", "'string'", 
                     "'void'", "'struct'", "','", "'+'", "'-'", "'*'", "'/'", 
                     "'!'", "'^'", "'('", "')'", "'TRUE'", "'FALSE'", "'print'", 
                     "<INVALID>", "'\t'", "'\n'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "NUMBER", "INDENT", "NEWLINE", "ID", "INT", "FLOAT", 
                      "STRING", "CHAR", "BLANK" ]

    RULE_simple_stmt = 0
    RULE_small_stmt = 1
    RULE_gv_stmt = 2
    RULE_decls = 3
    RULE_decl = 4
    RULE_vartype = 5
    RULE_tarlist = 6
    RULE_target = 7
    RULE_prmy = 8
    RULE_expr = 9
    RULE_term = 10
    RULE_unary = 11
    RULE_factor = 12
    RULE_output = 13

    ruleNames =  [ "simple_stmt", "small_stmt", "gv_stmt", "decls", "decl", 
                   "vartype", "tarlist", "target", "prmy", "expr", "term", 
                   "unary", "factor", "output" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    NUMBER=20
    INDENT=21
    NEWLINE=22
    ID=23
    INT=24
    FLOAT=25
    STRING=26
    CHAR=27
    BLANK=28

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None





    class Simple_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def small_stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(stuPydParser.Small_stmtContext)
            else:
                return self.getTypedRuleContext(stuPydParser.Small_stmtContext,i)


        def getRuleIndex(self):
            return stuPydParser.RULE_simple_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_stmt" ):
                listener.enterSimple_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_stmt" ):
                listener.exitSimple_stmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimple_stmt" ):
                return visitor.visitSimple_stmt(self)
            else:
                return visitor.visitChildren(self)




    def simple_stmt(self):

        localctx = stuPydParser.Simple_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_simple_stmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 29 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 28
                self.small_stmt()
                self.state = 31 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << stuPydParser.T__1) | (1 << stuPydParser.T__2) | (1 << stuPydParser.T__3) | (1 << stuPydParser.T__4) | (1 << stuPydParser.T__5) | (1 << stuPydParser.T__6) | (1 << stuPydParser.T__9) | (1 << stuPydParser.T__12) | (1 << stuPydParser.T__14) | (1 << stuPydParser.T__16) | (1 << stuPydParser.T__17) | (1 << stuPydParser.T__18) | (1 << stuPydParser.NUMBER) | (1 << stuPydParser.ID) | (1 << stuPydParser.STRING))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Small_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def decls(self):
            return self.getTypedRuleContext(stuPydParser.DeclsContext,0)


        def gv_stmt(self):
            return self.getTypedRuleContext(stuPydParser.Gv_stmtContext,0)


        def expr(self):
            return self.getTypedRuleContext(stuPydParser.ExprContext,0)


        def output(self):
            return self.getTypedRuleContext(stuPydParser.OutputContext,0)


        def getRuleIndex(self):
            return stuPydParser.RULE_small_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSmall_stmt" ):
                listener.enterSmall_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSmall_stmt" ):
                listener.exitSmall_stmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSmall_stmt" ):
                return visitor.visitSmall_stmt(self)
            else:
                return visitor.visitChildren(self)




    def small_stmt(self):

        localctx = stuPydParser.Small_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_small_stmt)
        try:
            self.state = 37
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 33
                self.decls()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 34
                self.gv_stmt()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 35
                self.expr(0)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 36
                self.output()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Gv_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(stuPydParser.ExprContext,0)


        def prmy(self):
            return self.getTypedRuleContext(stuPydParser.PrmyContext,0)


        def NEWLINE(self):
            return self.getToken(stuPydParser.NEWLINE, 0)

        def getRuleIndex(self):
            return stuPydParser.RULE_gv_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGv_stmt" ):
                listener.enterGv_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGv_stmt" ):
                listener.exitGv_stmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGv_stmt" ):
                return visitor.visitGv_stmt(self)
            else:
                return visitor.visitChildren(self)




    def gv_stmt(self):

        localctx = stuPydParser.Gv_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_gv_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 39
            self.expr(0)
            self.state = 40
            self.match(stuPydParser.T__0)
            self.state = 41
            self.prmy()
            self.state = 42
            self.match(stuPydParser.NEWLINE)


            	
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class DeclsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def decl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(stuPydParser.DeclContext)
            else:
                return self.getTypedRuleContext(stuPydParser.DeclContext,i)


        def getRuleIndex(self):
            return stuPydParser.RULE_decls

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDecls" ):
                listener.enterDecls(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDecls" ):
                listener.exitDecls(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDecls" ):
                return visitor.visitDecls(self)
            else:
                return visitor.visitChildren(self)




    def decls(self):

        localctx = stuPydParser.DeclsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_decls)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 46 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 45
                    self.decl()

                else:
                    raise NoViableAltException(self)
                self.state = 48 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class DeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def vartype(self):
            return self.getTypedRuleContext(stuPydParser.VartypeContext,0)


        def tarlist(self):
            return self.getTypedRuleContext(stuPydParser.TarlistContext,0)


        def NEWLINE(self):
            return self.getToken(stuPydParser.NEWLINE, 0)

        def getRuleIndex(self):
            return stuPydParser.RULE_decl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDecl" ):
                listener.enterDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDecl" ):
                listener.exitDecl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDecl" ):
                return visitor.visitDecl(self)
            else:
                return visitor.visitChildren(self)




    def decl(self):

        localctx = stuPydParser.DeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_decl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 50
            self.vartype()
            self.state = 51
            self.tarlist()
            self.state = 52
            self.match(stuPydParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VartypeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return stuPydParser.RULE_vartype

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVartype" ):
                listener.enterVartype(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVartype" ):
                listener.exitVartype(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVartype" ):
                return visitor.visitVartype(self)
            else:
                return visitor.visitChildren(self)




    def vartype(self):

        localctx = stuPydParser.VartypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_vartype)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 54
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << stuPydParser.T__1) | (1 << stuPydParser.T__2) | (1 << stuPydParser.T__3) | (1 << stuPydParser.T__4) | (1 << stuPydParser.T__5) | (1 << stuPydParser.T__6))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TarlistContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def target(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(stuPydParser.TargetContext)
            else:
                return self.getTypedRuleContext(stuPydParser.TargetContext,i)


        def getRuleIndex(self):
            return stuPydParser.RULE_tarlist

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTarlist" ):
                listener.enterTarlist(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTarlist" ):
                listener.exitTarlist(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTarlist" ):
                return visitor.visitTarlist(self)
            else:
                return visitor.visitChildren(self)




    def tarlist(self):

        localctx = stuPydParser.TarlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_tarlist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 56
            self.target()
            self.state = 61
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==stuPydParser.T__7:
                self.state = 57
                self.match(stuPydParser.T__7)
                self.state = 58
                self.target()
                self.state = 63
                self._errHandler.sync(self)
                _la = self._input.LA(1)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TargetContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(stuPydParser.ID, 0)

        def getRuleIndex(self):
            return stuPydParser.RULE_target

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTarget" ):
                listener.enterTarget(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTarget" ):
                listener.exitTarget(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTarget" ):
                return visitor.visitTarget(self)
            else:
                return visitor.visitChildren(self)




    def target(self):

        localctx = stuPydParser.TargetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_target)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 66
            self.match(stuPydParser.ID)


            	
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class PrmyContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(stuPydParser.ID, 0)

        def getRuleIndex(self):
            return stuPydParser.RULE_prmy

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrmy" ):
                listener.enterPrmy(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrmy" ):
                listener.exitPrmy(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrmy" ):
                return visitor.visitPrmy(self)
            else:
                return visitor.visitChildren(self)




    def prmy(self):

        localctx = stuPydParser.PrmyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_prmy)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self.match(stuPydParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return stuPydParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class EtermContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(stuPydParser.TermContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEterm" ):
                listener.enterEterm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEterm" ):
                listener.exitEterm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEterm" ):
                return visitor.visitEterm(self)
            else:
                return visitor.visitChildren(self)


    class EsubContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(stuPydParser.ExprContext,0)

        def term(self):
            return self.getTypedRuleContext(stuPydParser.TermContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEsub" ):
                listener.enterEsub(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEsub" ):
                listener.exitEsub(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEsub" ):
                return visitor.visitEsub(self)
            else:
                return visitor.visitChildren(self)


    class EaddContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(stuPydParser.ExprContext,0)

        def term(self):
            return self.getTypedRuleContext(stuPydParser.TermContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEadd" ):
                listener.enterEadd(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEadd" ):
                listener.exitEadd(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEadd" ):
                return visitor.visitEadd(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = stuPydParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 18
        self.enterRecursionRule(localctx, 18, self.RULE_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = stuPydParser.EtermContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 72
            self.term(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 82
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 80
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                    if la_ == 1:
                        localctx = stuPydParser.EaddContext(self, stuPydParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 74
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 75
                        self.match(stuPydParser.T__8)
                        self.state = 76
                        self.term(0)
                        pass

                    elif la_ == 2:
                        localctx = stuPydParser.EsubContext(self, stuPydParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 77
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 78
                        self.match(stuPydParser.T__9)
                        self.state = 79
                        self.term(0)
                        pass

             
                self.state = 84
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class TermContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return stuPydParser.RULE_term

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class TunaryContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def unary(self):
            return self.getTypedRuleContext(stuPydParser.UnaryContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTunary" ):
                listener.enterTunary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTunary" ):
                listener.exitTunary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTunary" ):
                return visitor.visitTunary(self)
            else:
                return visitor.visitChildren(self)


    class TmulContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(stuPydParser.TermContext,0)

        def unary(self):
            return self.getTypedRuleContext(stuPydParser.UnaryContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTmul" ):
                listener.enterTmul(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTmul" ):
                listener.exitTmul(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTmul" ):
                return visitor.visitTmul(self)
            else:
                return visitor.visitChildren(self)


    class TdivContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(stuPydParser.TermContext,0)

        def unary(self):
            return self.getTypedRuleContext(stuPydParser.UnaryContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTdiv" ):
                listener.enterTdiv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTdiv" ):
                listener.exitTdiv(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTdiv" ):
                return visitor.visitTdiv(self)
            else:
                return visitor.visitChildren(self)



    def term(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = stuPydParser.TermContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 20
        self.enterRecursionRule(localctx, 20, self.RULE_term, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = stuPydParser.TunaryContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 86
            self.unary(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 96
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 94
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                    if la_ == 1:
                        localctx = stuPydParser.TmulContext(self, stuPydParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 88
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 89
                        self.match(stuPydParser.T__10)
                        self.state = 90
                        self.unary(0)
                        pass

                    elif la_ == 2:
                        localctx = stuPydParser.TdivContext(self, stuPydParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 91
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 92
                        self.match(stuPydParser.T__11)
                        self.state = 93
                        self.unary(0)
                        pass

             
                self.state = 98
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class UnaryContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return stuPydParser.RULE_unary

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class UdisContext(UnaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.UnaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def unary(self):
            return self.getTypedRuleContext(stuPydParser.UnaryContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUdis" ):
                listener.enterUdis(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUdis" ):
                listener.exitUdis(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUdis" ):
                return visitor.visitUdis(self)
            else:
                return visitor.visitChildren(self)


    class UnotContext(UnaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.UnaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def unary(self):
            return self.getTypedRuleContext(stuPydParser.UnaryContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnot" ):
                listener.enterUnot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnot" ):
                listener.exitUnot(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnot" ):
                return visitor.visitUnot(self)
            else:
                return visitor.visitChildren(self)


    class UsqrContext(UnaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.UnaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def unary(self):
            return self.getTypedRuleContext(stuPydParser.UnaryContext,0)

        def factor(self):
            return self.getTypedRuleContext(stuPydParser.FactorContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUsqr" ):
                listener.enterUsqr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUsqr" ):
                listener.exitUsqr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUsqr" ):
                return visitor.visitUsqr(self)
            else:
                return visitor.visitChildren(self)


    class UfacContext(UnaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.UnaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def factor(self):
            return self.getTypedRuleContext(stuPydParser.FactorContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUfac" ):
                listener.enterUfac(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUfac" ):
                listener.exitUfac(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUfac" ):
                return visitor.visitUfac(self)
            else:
                return visitor.visitChildren(self)



    def unary(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = stuPydParser.UnaryContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 22
        self.enterRecursionRule(localctx, 22, self.RULE_unary, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [stuPydParser.T__12]:
                localctx = stuPydParser.UnotContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 100
                self.match(stuPydParser.T__12)
                self.state = 101
                self.unary(4)
                pass
            elif token in [stuPydParser.T__9]:
                localctx = stuPydParser.UdisContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 102
                self.match(stuPydParser.T__9)
                self.state = 103
                self.unary(3)
                pass
            elif token in [stuPydParser.T__14, stuPydParser.T__16, stuPydParser.T__17, stuPydParser.NUMBER, stuPydParser.ID, stuPydParser.STRING]:
                localctx = stuPydParser.UfacContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 104
                self.factor()
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 112
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = stuPydParser.UsqrContext(self, stuPydParser.UnaryContext(self, _parentctx, _parentState))
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_unary)
                    self.state = 107
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 108
                    self.match(stuPydParser.T__13)
                    self.state = 109
                    self.factor() 
                self.state = 114
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class FactorContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return stuPydParser.RULE_factor

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class FnumContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(stuPydParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFnum" ):
                listener.enterFnum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFnum" ):
                listener.exitFnum(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFnum" ):
                return visitor.visitFnum(self)
            else:
                return visitor.visitChildren(self)


    class FfalseContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFfalse" ):
                listener.enterFfalse(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFfalse" ):
                listener.exitFfalse(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFfalse" ):
                return visitor.visitFfalse(self)
            else:
                return visitor.visitChildren(self)


    class FtrueContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFtrue" ):
                listener.enterFtrue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFtrue" ):
                listener.exitFtrue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFtrue" ):
                return visitor.visitFtrue(self)
            else:
                return visitor.visitChildren(self)


    class FincContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(stuPydParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFinc" ):
                listener.enterFinc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFinc" ):
                listener.exitFinc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFinc" ):
                return visitor.visitFinc(self)
            else:
                return visitor.visitChildren(self)


    class FStringContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(stuPydParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFString" ):
                listener.enterFString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFString" ):
                listener.exitFString(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFString" ):
                return visitor.visitFString(self)
            else:
                return visitor.visitChildren(self)


    class FprmyContext(FactorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a stuPydParser.FactorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def prmy(self):
            return self.getTypedRuleContext(stuPydParser.PrmyContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFprmy" ):
                listener.enterFprmy(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFprmy" ):
                listener.exitFprmy(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFprmy" ):
                return visitor.visitFprmy(self)
            else:
                return visitor.visitChildren(self)



    def factor(self):

        localctx = stuPydParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_factor)
        try:
            self.state = 124
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [stuPydParser.NUMBER]:
                localctx = stuPydParser.FnumContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 115
                self.match(stuPydParser.NUMBER)
                pass
            elif token in [stuPydParser.T__14]:
                localctx = stuPydParser.FincContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 116
                self.match(stuPydParser.T__14)
                self.state = 117
                self.expr(0)
                self.state = 118
                self.match(stuPydParser.T__15)
                pass
            elif token in [stuPydParser.T__16]:
                localctx = stuPydParser.FtrueContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 120
                self.match(stuPydParser.T__16)
                pass
            elif token in [stuPydParser.T__17]:
                localctx = stuPydParser.FfalseContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 121
                self.match(stuPydParser.T__17)
                pass
            elif token in [stuPydParser.STRING]:
                localctx = stuPydParser.FStringContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 122
                self.match(stuPydParser.STRING)
                pass
            elif token in [stuPydParser.ID]:
                localctx = stuPydParser.FprmyContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 123
                self.prmy()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class OutputContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(stuPydParser.ID, 0)

        def NEWLINE(self):
            return self.getToken(stuPydParser.NEWLINE, 0)

        def getRuleIndex(self):
            return stuPydParser.RULE_output

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOutput" ):
                listener.enterOutput(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOutput" ):
                listener.exitOutput(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOutput" ):
                return visitor.visitOutput(self)
            else:
                return visitor.visitChildren(self)




    def output(self):

        localctx = stuPydParser.OutputContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_output)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(stuPydParser.T__18)
            self.state = 127
            self.match(stuPydParser.T__14)
            self.state = 128
            self.match(stuPydParser.ID)
            self.state = 129
            self.match(stuPydParser.T__15)
            self.state = 130
            self.match(stuPydParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[9] = self.expr_sempred
        self._predicates[10] = self.term_sempred
        self._predicates[11] = self.unary_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         

    def term_sempred(self, localctx:TermContext, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 2)
         

    def unary_sempred(self, localctx:UnaryContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 2)
         




